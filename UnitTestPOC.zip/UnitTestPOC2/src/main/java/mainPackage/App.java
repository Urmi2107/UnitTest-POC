package mainPackage;

public class App {

	MyDao myDao;
	
	public App(MyDao myDao) {
		this.myDao=myDao;
	}
	
	public Employee method(Integer id) {
		LambdaHandler ob=new LambdaHandler(myDao);
		Employee result = ob.handleRequest(id,null);
		return result;
	}
}
