package mainPackage;

public class MyDao {
	 
	  public Employee findById(int id) {
	    throw new UnsupportedOperationException();
	  }
	}