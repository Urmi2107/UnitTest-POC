package mainPackage;

public class MyService {
	 
	  private MyDao myDao;
	 
	  public MyService(MyDao myDao) {
	    this.myDao = myDao;
	  }
	  public Employee findById(int id) {
	    return myDao.findById(id);
	  }
	}