package mainPackage;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class LambdaHandler implements RequestHandler<Integer,Employee> {
	
	private MyDao myDao;
	
	public LambdaHandler(MyDao myDao) {
		this.myDao=myDao;
	}
	
	public Employee handleRequest(Integer id, Context context) {
	   
	   MyService myService=new MyService(myDao);
       Employee emp = myService.findById(id);
       return emp;
    }
}
