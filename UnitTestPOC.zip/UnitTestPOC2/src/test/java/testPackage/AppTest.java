package testPackage;

import static org.mockito.Mockito.mock;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import mainPackage.MyDao;
import mainPackage.App;
import mainPackage.Employee;

public class AppTest {
 
  @Rule public MockitoRule rule = MockitoJUnit.rule();
 
  @ParameterizedTest
  @ValueSource(ints = {1,3,7})
  public void test(Integer id) {
	  
	MyDao myDao = mock(MyDao.class);
    Mockito.when(myDao.findById(id)).thenReturn(createTestEntity());
    App app = new App(myDao);
    Employee response = app.method(id);
    Assert.assertEquals("Abc", response.getFirstName());
    Assert.assertEquals("Xyz", response.getSurname());
}
 
  private Employee createTestEntity() {
	  
	Employee employee = new Employee();
	employee.setFirstName("Abc");
	employee.setSurname("Xyz");
    return employee;
  }
}