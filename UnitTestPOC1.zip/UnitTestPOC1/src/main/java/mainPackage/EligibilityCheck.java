package mainPackage;

public class EligibilityCheck {
	int year;
	
	public EligibilityCheck(int year) {
		this.year=year;
	}
	
	public String eligibility(){
		if(year>0) {
			return "Eligible";
		}
		return "Ineligible";
	}
}
