package mainPackage;

import java.util.HashMap;
import java.util.Map;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;

public class LambdaHandler implements RequestHandler<APIGatewayProxyRequestEvent,APIGatewayProxyResponseEvent> {
    
	public APIGatewayProxyResponseEvent handleRequest(APIGatewayProxyRequestEvent event, Context context) {
       Map<String, String> headers = new HashMap<>();
       headers.put("Content-Type", "application/json");
       headers.put("X-Custom-Header", "application/json");
       APIGatewayProxyResponseEvent response = new APIGatewayProxyResponseEvent().withHeaders(headers);
       try 
       {
    	   String output="";
    	   Integer year=Integer.parseInt(event.getBody());
    	   if(checkLeap(year)==1)
              output="Leap";
           else
              exceptionGeneration();
      	   return response
             .withStatusCode(200)
             .withBody(output);
       }
       catch(Exception e) {
    	   return response
             .withStatusCode(500)
             .withBody("{}");
       }
    }
    private int checkLeap(int year){
    	if(year%100==0) {
    		if(year%400==0)
    			return 1;
    	}else {
    		if(year%4==0)
    			return 1;
    	}
    	return 0;
    	}
    private int exceptionGeneration() {
    	return 2/0;
    }
}