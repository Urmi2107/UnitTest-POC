package mainPackage;

import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;

public class App {

	Integer year;
	String elgChk;
	
	public App(int year, String elgChk) {
		this.year=year;
		this.elgChk=elgChk;
	}
	
	public APIGatewayProxyResponseEvent method() {
		if(elgChk.equalsIgnoreCase("eligible")){
			LambdaHandler ob=new LambdaHandler();
			APIGatewayProxyRequestEvent request = new APIGatewayProxyRequestEvent();
		    APIGatewayProxyResponseEvent result = ob.handleRequest(request.withBody(year.toString()),null);
		    return result;
		}
		else {
			APIGatewayProxyResponseEvent response = new APIGatewayProxyResponseEvent();
			return response.withBody("Invalid").withStatusCode(500);
		}
	}

}
