package testPackage;
import org.junit.jupiter.api.Test;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import mainPackage.App;
import mainPackage.EligibilityCheck;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class AppTest {
	
	@ParameterizedTest
	@ValueSource(ints = {2000,2008,2012,2020,2024})
  public void successfulStringResponse(Integer year) {
	
	EligibilityCheck elg = mock(EligibilityCheck.class);
	when(elg.eligibility()).thenReturn("eligible");
		   
    App app=new App(year,elg.eligibility());
    APIGatewayProxyResponseEvent result=app.method();
    
    assertEquals(200, result.getStatusCode().intValue());
    assertEquals("application/json", result.getHeaders().get("Content-Type"));
    String content = result.getBody();
    assertNotNull(content);
    assertTrue(content.equalsIgnoreCase("leap"));
  }
	
	@ParameterizedTest
	@ValueSource(ints = {2001,2005,1900,2010,2022})
	public void successfulExceptionResponse(Integer year) {
		
		EligibilityCheck elg = mock(EligibilityCheck.class);
		when(elg.eligibility()).thenReturn("eligible");
			   
	    App app=new App(year,elg.eligibility());
	    APIGatewayProxyResponseEvent result=app.method();
	    
	    assertEquals(500, result.getStatusCode().intValue());
		assertFalse(result.getBody().contains("leap"));
	}
	
	@Test
      public void assertThrowsException() {
        String str = null;
	    assertThrows(IllegalArgumentException.class, () -> {
	    Integer.valueOf(str);
	 });
   }
}